/**
 * Created by anye on 2017/7/17.
 */
import {StyleSheet,
StatusBar} from 'react-native';

import Colors from '../../utils/Colors';
export default statusBarStyle=StyleSheet.create({
    container: {
        flex: 1,

        backgroundColor:Colors.statusBarColor
    },
})