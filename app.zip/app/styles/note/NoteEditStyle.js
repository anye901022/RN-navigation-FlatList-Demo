/**
 * Created by anye on 2017/7/17.
 */
import React from 'react';
import  {StyleSheet} from 'react-native';
import  Colors from '../../utils/Colors';
export  default  NoteEditStyle=StyleSheet.create({

    inputStyle:{
        height:40,
        margin:20,
        borderBottomColor: '#000000',
        borderBottomWidth: 1
    }
})