/**
 * Created by anye on 2017/7/17.
 */
import {StyleSheet} from 'react-native';

import Colors from '../../../utils/Colors';

export default DiscoveryStyle=StyleSheet.create({

    icon: {
        width: 25,
        height: 25
    }
})