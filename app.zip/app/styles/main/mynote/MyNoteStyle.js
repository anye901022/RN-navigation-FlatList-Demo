/**
 * Created by anye on 2017/7/17.
 */
import {StyleSheet} from 'react-native';


export default MyNoteStyle=StyleSheet.create({

})