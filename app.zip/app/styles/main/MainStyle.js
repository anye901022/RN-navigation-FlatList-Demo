/**
 * Created by anye on 2017/6/24.
 */
import {StyleSheet} from 'react-native';


export default MainStyle=StyleSheet.create({
    icon: {
        width: 24,
        height: 24
    },

})