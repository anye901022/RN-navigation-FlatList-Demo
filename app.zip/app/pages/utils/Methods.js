/**
 * Created by anye on 2017/7/17.
 */
import {
    StyleSheet,

} from 'react-native';

const HORIZ_WIDTH = 200;
const ITEM_HEIGHT = 72;
const HEADER = {height: 30, width: 100};
const SEPARATOR_HEIGHT = StyleSheet.hairlineWidth;

export  function getItemLayout(data: any, index: number, horizontal?: boolean) {
    const [length, separator, header] = horizontal ?
        [HORIZ_WIDTH, 0, HEADER.width] : [ITEM_HEIGHT, SEPARATOR_HEIGHT, HEADER.height];
    return {length, offset: (length + separator) * index + header, index};
}

