/**
 * Created by anye on 2017/7/17.
 */
import React, {PureComponent} from 'react';
import {
    View,
    Text,
    Image
} from 'react-native';

export default class NoteItem extends PureComponent {


    render() {
        return (
            <View>
                <Text>
                    哈哈哈
                </Text>
            </View>
        )
    }
}