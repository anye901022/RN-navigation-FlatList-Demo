/**
 * Created by anye on 2017/7/17.
 */
export  default class Colors{
    static statusBarColor="#48b4ff";
    static bg_bottom='#EFEDED';
    static Buy_item_title_color='#333333';
    static Buy_item_select_color='#666666';
    static statusBarFontColor='#fff';
    static transparent="#00000000";
    static pageBG="#F5F5F5";

}